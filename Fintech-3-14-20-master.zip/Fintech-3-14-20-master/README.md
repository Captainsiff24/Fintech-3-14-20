# Fintech-3-14-20
Day 3 of class
